This is the level editor for my homebrew platform game Bob's Fury.

Like the game itself it's a work in progress, please leave any feedback on my blog.
https://sparcie.wordpress.com/

There is only one level included, a test level which I've used for testing
features of the game engine when.

Requirements
------------

Being a slimer and simpler program it doesn't support as much hardware as the game does.
Only VGA and SVGA are supported for graphics, and PC speaker for sound.
It should work on a 286 machine with around 300-400k of RAM.

Future
------

This is a work in progress like the game, and I basically update things when I feel like it.
However I have a few minor changes in mind.

- The level tester uses easy by default, I may add the ability to change the difficulty.
- The editor doesn't remember it's configuration, something I may change.
- The control scheme for the tester is the oldest one, and can be clunky.
  I will eventually update this to be the same as that in the game.
  
Command Line
------------

bfleu -h -l

-l uses the VGA (320x200) graphics mode (default)
-h uses the SVGA (640x400) graphics mode.

Basic Key Reference
-------------------

F1 - Shows the help screen which gives this information.
F2 - Save the current level
F3 - Load a level
F4 - Floodfill an area.
F8 - Start the level tester
F9 - New empty level.
F10 - Quit (no prompting!)

Arrow keys - move the cursor around.
, and . - change the item that will be placed
Enter - places the current item
Space - toggles a draw mode
S - To set the level size (can only be done once)
M - shows a minimap of the entire level
PageUp/PageDown - change screen vertically
Home/End - change screen horizontally
T - add a trigger (once at source, again at the target.)
U - delete trigger at cursor
F - Follow trigger to target

Please see the help in the program for more information.

License
-------

Like the game this is freeware. That means you get to play with it for free, but I still own it.
