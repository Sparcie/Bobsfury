Thanks for downloading my homebrew DOS game Bob's Fury.
If you have any comments or feedback I'd be glad to hear them, please comment at my blog.
http://sparcie.wordpress.com/2014/11/11/download-for-bobs-fury/

It's a work in progress (ie. it's not complete) and includes two sets of levels from the much older
Qbasic version of the game I wrote as a teenager.

Requirements
------------
The game requires about 200-300K of memory and a 286 processor as well as a graphics card (CGA, EGA, VGA or VESA/SVGA).
If you are running on a slow machine such as a 286 and are experiencing slow down, you should try a
different video mode. The speed of the modes from slowest to fastest is: VESA/SVGA, EGA, VGA, CGA. Select one
suitable for your hardware.

The game supports Adlib, PC speaker and the OPLxLPT devices which you can select with command line options.  
The default behaviour is to use Adlib if detected and fall back to PC speaker if it isn't.
Music support has been made, but I haven't made any serious effort to compose any suitable music yet
(the available music is for testing only), this option is best left turned off.

The game remembers the hardware configuration between sessions, command line switches are only required to change
what is currently used.


Trouble shooting Tips
---------------------
I have done some testing on real hardware, but since what I have is extremely limited I can't guarantee
it will work perfectly on your system. Dosbox works quite well with pretty much the default settings. If you
have a problem please report a bug by posting a comment on my blog.

If you have problems try a different sound device or disable doubling the PIT speed.

Future
------
I'm obviously still working on this so changes will be made over time, hopefully adding more levels, but
perhaps also other features as I need them. I'm doing this in my spare time, of which I have very little,
so progress is slow. There will be updates, but there may be some significant time between them.

I have released the level editor, but I don't have any plans to release source code.
This is mostly because it's a bit untidy and much of it was written when I was inexperienced. 

Some things I don't plan on changing.
 - I'm not going to add smooth scrolling. It would be too big a change to the code base and wouldn't be
      faithful to the QBasic original. Although I am now considering re-writing much of the graphics support
      for better performance.
 - I'm not going to add digitised Sound blaster sound. I am considering adding CMS support but it's not planned
      at this stage.

Command Line
------------

bob /? -e -cga -h -l -n -a -s -c <file.map>

/? = shows a list of command line options

-e   = EGA graphics mode (640x200x16)
-cga = CGA graphics mode (320x200x4)
-l   = VGA graphics mode (320x200x256) (default)
-h   = VESA/SVGA graphics mode (640x400x256)

-n   = Force sound to be turned off.
-a   = Auto detect Adlib or PC Speaker
-s   = Force using the PC Speaker
LPT1 = use the OPL2LPT on LPT1
LPT2 = use the OPL2LPT on LPT2

-np  = disable doubling the PIT speed

-c <File.map> = used for loading a level directly.

License
-------

Bob's Fury is Freeware. This means you get to play with it for free, but I still own it.
